This application is meant to help schedule tee times at a private golf course and is invite only.

The application is covered under the GNU license agreement and may only be copied or used with written permission by the author.

Author: Alex Coffin